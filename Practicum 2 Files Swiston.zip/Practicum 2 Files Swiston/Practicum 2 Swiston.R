#' ---
#' title: "Practicum 2"
#' author: "Bryn Swiston"
#' format:
#'   pdf:
#'     fig-width: 8
#'     fig-height: 6
#' execute:
#'   echo: false
#'   warning: false
#'   message: false
#'   output: false
#' ---
#' 
## --------------------------------------------------------------------------------------------------------------
#I will now open and activate the necessary libraries
library(tidyverse)
library(sf)
library(tidycensus)

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now read in the county data
uscounties <- st_read("cb_2024_us_county_500k.shp", quiet = TRUE)

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now filter down that data to just New York State
nycounties <- uscounties |>
  filter(STATEFP == "36")

#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will map out New York State
rawcountymap <- ggplot() + 
  geom_sf(data = nycounties) +
  labs(title = "New York State Counties",
       caption = "Source: U.S. Census Bureau’s Cartographic Boundary Files") +
  theme_void()

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now find the largest and smallest counties by land area
nycounties |> slice_min(ALAND, n = 1)
nycounties |> slice_max(ALAND, n = 1)
#The smallest county by land area is New York County, and the largest is St. Lawrence County.

#' 
## --------------------------------------------------------------------------------------------------------------
#I will not read in the high points data
nyhighpts <- read.csv("nyshighpoints.csv")

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now add the highpoints to the original map. 
grayhighptmap<- ggplot() + 
  geom_sf(data = nycounties) +
  geom_point(data = nyhighpts, mapping = aes(x = Longitude, y = Latitude)) +
  labs(title = "New York State Counties and High Points",
       caption = "Source: U.S. Census Bureau’s Cartographic Boundary Files and Course Files") +   theme_void()

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now color the points based on elevation.
highptmap <- ggplot() +
  geom_sf(data = nycounties) +
  geom_point(
    data = nyhighpts,
    mapping = aes(x = Longitude, y = Latitude, color = Elevation_Meters),
    size = 3, alpha = 1
  ) +
  scale_color_gradientn(
    colors = c("darkgreen", "orange", "red", "purple"),
    name = "Elevation (m)"
  ) +
  labs(
    title = "New York State Counties and High Points",
    caption = "Source: U.S. Census Bureau's Cartographic Boundary Files and Course Files"
  ) +
  theme_void()

highptmap

#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will find the highest and lowest "high points" in the state. 
nyhighpts |> slice_min(Elevation_Meters, n = 1)
nyhighpts |> slice_max(Elevation_Meters, n = 1)
#The lowest "high point" is Battle Hill and the highest "hight point" is Mount Marcy. 

#' 
## --------------------------------------------------------------------------------------------------------------
#I will now add a label to Mount Marcy on the map. 
library(ggrepel)
highptmapMM <- ggplot() +
  geom_sf(data = nycounties) +
  geom_point(
    data = nyhighpts,
    mapping = aes(x = Longitude, y = Latitude, color = Elevation_Meters),
    size = 3, alpha = 1
  ) +
  geom_text_repel(
    data = filter(nyhighpts, High_Point_Name == "Mount Marcy"),
    mapping = aes(x = Longitude, y = Latitude, label = High_Point_Name),
    nudge_x = 1.2,
    nudge_y = 0.6,
    min.segment.length = 0,
    segment.size = .5,
    fontface = "bold",
    size = 4
  ) +
  scale_color_gradientn(
    colors = c("darkgreen", "orange", "red", "purple"),
    name = "Elevation (m)"
  ) +
  labs(
    title = "New York State Counties and High Points",
    caption = "Source: U.S. Census Bureau's Cartographic Boundary Files and Course Files"
  ) +
  theme_void()

#' 
## --------------------------------------------------------------------------------------------------------------
#| output: true
highptmapMM

#' 
#' ## Figure 1
#' 
#' #### This map shows a map of New York counties and color-coded high points, with the highest point labeled. The highest high point is Mount Marcy, with an elevation of 1629 meters. The lowest high point is Battle Hill, with an elevation of 67 meters. 
#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will get the New York Census Data
readRenviron("~/.Renviron")
nypopulation <- get_acs(
  geography = "county",
  variables = "B01003_001",
  state = "NY",
  year = 2023,
  geometry = TRUE
)

#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will plot the population map for NY. 
nypopulationmap <- ggplot(nypopulation) +
  geom_sf(aes(fill = estimate), color = "gray40", linewidth = 0.2) +
  scale_fill_gradientn(
    colors = c("lightyellow", "goldenrod1", "darkorange3", "darkorange4"),
    trans = "log10",
    name = "Population",
    labels = scales::comma
  ) +
  labs(
    title = "New York State County Population",
    caption = "Source: U.S. Census Bureau, American Community Survey"
  ) +
  theme_void()


#' 
## --------------------------------------------------------------------------------------------------------------
#| output: true
nypopulationmap

#' 
#' ## Figure 2
#' 
#' #### This map shows New York state population by county. The most populous county is Kings County, the least populous is Hamilton County.
#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will calculate population density
nydensity <- nypopulation |>
  left_join(
    nycounties |> st_drop_geometry() |> select(GEOID, ALAND),
    by = "GEOID"
  ) |>
  mutate(density = estimate / (ALAND / 1e6))

#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will build the map
nydensitymap <- ggplot(nydensity) +
  geom_sf(aes(fill = density), color = "gray40", linewidth = 0.2) +
  scale_fill_gradientn(
    colors = c("lavender", "mediumpurple", "purple3", "darkviolet"),
    trans = "log10",
    name = "People per km²",
    labels = scales::comma
  ) +
  labs(
    title = "New York State Population Density by County",
    caption = "Source: U.S. Census Bureau, American Community Survey and Cartographic Boundary Files"
  ) +
  theme_void()

#' 
## --------------------------------------------------------------------------------------------------------------
#| output: true
nydensitymap

#' 
#' ## Figure 3
#' 
#' #### This map shows population density by county in New York State. The most densely populated county is New York County, the least densely populated is Hamilton County.
#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will find the largest and smallest counties in New York by population
nypopulation |> slice_min(estimate, n = 1)
nypopulation |> slice_max(estimate, n = 1)
#The largest county is Kings County, the smallest is Hamilton County.

#' 
## --------------------------------------------------------------------------------------------------------------
#Now I will find the most and least dense counties in New York
nydensity |> slice_min(density, n = 1)
nydensity |> slice_max(density, n = 1)
#The most dense county is New York County, the least dense is Hamilton County.

